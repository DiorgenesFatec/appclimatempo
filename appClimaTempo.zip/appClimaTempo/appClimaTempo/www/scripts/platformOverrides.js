﻿/*
	Este arquivo é substituído pelo código específico da plataforma da pasta /merges.
	Obtenha mais informações em http://taco.visualstudio.com/pt-br/docs/configure-app/#Content.
*/